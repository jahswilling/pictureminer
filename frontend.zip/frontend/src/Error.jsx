import React from 'react';

const ErrorPage = () => {
  return (
    <>
      <div className="Error__Container">Page Not Found</div>
    </>
  );
};

export default ErrorPage;
